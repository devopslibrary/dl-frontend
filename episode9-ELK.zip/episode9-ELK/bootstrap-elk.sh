#!/usr/bin/env bash

# First copy bashrc file that enables color text, I hate BW :(
cp /vagrant/bashrc /home/vagrant/.bashrc
cp /vagrant/bashrc /root/.bashrc

hostname elk
echo "192.168.5.10 elk" | tee -a /etc/hosts